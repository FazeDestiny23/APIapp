//
//  APIappApp.swift
//  APIapp
//
//  Created by FRANCISCO AQUINO on 05/04/24.
//

import SwiftUI

@main
struct APIappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
